/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 *
 * @format
 * @oncall react_native
 */

declare class ResourceNotFoundError extends Error {
  resourcePath: string;
  constructor(resourcePath: string);
}
export default ResourceNotFoundError;